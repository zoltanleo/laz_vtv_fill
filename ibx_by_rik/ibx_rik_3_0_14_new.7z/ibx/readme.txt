IBX for Lazarus is derived from the Open Source edition of IBX published by Borland/Inprise in 
2000 under the InterBase Public License. This version has been brought up-to-date by MWA Software
(http://www.mwasoftware.co.uk) and focused on the Firebird Database API for both Linux and Windows
platforms. It is released under the InterBase Public License for the original code and under the
compatible Initial Developers Public License for new software.

See the "doc" directory for more information and installation instructions.

mailto: ibx@mwasoftware.co.uk 

